## CME Month Codes

You can find them here

http://www.cmegroup.com/month-codes.html

Here they are for quick access:

| Month | Month Code |
|-------|------------|
| Jan   | F          |
| Feb   | G          |
| Mar   | H          |
| Apr   | J          |
| May   | K          |
| Jun   | M          |
| Jul   | N          |
| Aug   | Q          |
| Sep   | U          |
| Oct   | V          |
| Nov   | X          |
| Dec   | Z          |
