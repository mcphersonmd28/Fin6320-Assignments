#Install Libraries

library(urca)
library(tseries)
library(zoo)
library(lubridate)
library(XRJulia)
library(JuliaCall)

#Set the working directory

setwd("C:\\Users\\maddi\\Documents\\Masters 2017-2018\\Second Semester\\Computational Methods\\Project")

#Read Data

raw.Data <- read.csv("Hog-Cycle-Data.csv", header = TRUE)
head(raw.Data)
tail(raw.Data)

#Transform corn, soybean, and hog to match each other in units
#They should all now be in cents

he <- 0.74 * (raw.Data$HE.Close / 100)
c <- raw.Data$C.Close / 100
sm <- raw.Data$SM.Close

#create month dummy variables

begDate <- as.Date("1985-01-02", "%Y-%m-%d")
begDate
endDate <- as.Date("2001-12-31", "%Y-%m-%d")
endDate
#dt <- seq.Date(from=begDate, to=endDate, by="day")
dt <- as.Date(raw.Data$Date, "%Y-%m-%d")
ind1 <- month(dt) == 1
ind2 <- month(dt) == 2
ind3 <- month(dt) == 3
ind4 <- month(dt) == 4
ind5 <- month(dt) == 5
ind6 <- month(dt) == 6
ind7 <- month(dt) == 7
ind8 <- month(dt) == 8
ind9 <- month(dt) == 9
ind10 <- month(dt) == 10
ind11 <- month(dt) == 11
ind12 <- month(dt) == 12

#replace all n with n.dt
n.dt <- length(dt)
D1 <- rep(0, n.dt)
D1[ind1] <- 1
D2 <- rep(0, n.dt)
D2[ind2] <- 1
D3 <- rep(0, n.dt)
D3[ind3] <- 1
D4 <- rep(0, n.dt)
D4[ind4] <- 1
D5 <- rep(0, n.dt)
D5[ind5] <- 1
D6 <- rep(0, n.dt)
D6[ind6] <- 1
D7 <- rep(0, n.dt)
D7[ind7] <- 1
#D8 <- rep(0, n)
#D8[ind8] <- 1
D9 <- rep(0, n.dt)
D9[ind9] <- 1
D10 <- rep(0, n.dt)
D10[ind10] <- 1
D11 <- rep(0, n.dt)
D11[ind11] <- 1
D12 <- rep(0, n.dt)
D12[ind12] <- 1


#create zoo variables

z.he <- zoo(he, raw.Data$Date)
z.c <- zoo(c, raw.Data$Date)
z.sm <- zoo(sm, raw.Data$Date)
product.full <- merge(z.he, z.c, z.sm, all = FALSE)

#plot to make sure we've got it right
#Plot doesn't work.  Figure that out later

plot(product.full, screens = 1, lwd = 2, type = "l", col = c("blue", "orange", "green"))

#adf tests for hog, corn, and soybean in levels

adf.he <- ur.df(he, type = "none", selectlags = "BIC")
summary(adf.he)
adf.c <- ur.df(c, type = "none", selectlags = "BIC")
summary(adf.c)
adf.sm <- ur.df(sm, type = "none", selectlags = "BIC")
summary(adf.sm)

#adf test for level differences?

he.diff <- diff(he)
c.diff <- diff(c)
sm.diff <- diff(sm)

adf.he.diff <- ur.df(he.diff, type = "none", selectlags = "BIC")
summary(adf.he.diff)
adf.c.diff <- ur.df(c.diff, type = "none", selectlags = "BIC")
summary(adf.c.diff)
adf.sm.diff <- ur.df(sm.diff, type = "none", selectlags = "BIC")
summary(adf.sm.diff)

### Don't need to test in logs or log levels or log differences

#adf test for log hog, corn, and soybean
#adf.log.he <- ur.df(log(raw.Data$HE.Close), type = "none", selectlags = "BIC")
#summary(adf.log.he)
#adf.log.c <- ur.df(log(raw.Data$C.Close), type = "none", selectlags = "BIC")
#summary(adf.log.c)
#adf.log.sm <- ur.df(log(raw.Data$SM.Close), type = "none", selectlags = "BIC")
#summary(adf.log.sm)

#adf test for log differences
#he.diff <- diff(log(raw.Data$HE.Close))
#c.diff <- diff(log(raw.Data$C.Close))
#sm.diff <- diff(log(raw.Data$SM.Close))

#adf.he.diff <- ur.df(he.diff, type = "none", selectlags = "BIC")
#summary(adf.he.diff)
#adf.c.diff <- ur.df(c.diff, type = "none", selectlags = "BIC")
#summary(adf.c.diff)
#adf.sm.diff <- ur.df(sm.diff, type = "none", selectlags = "BIC")
#summary(adf.sm.diff)

#Part 1: Engle-Granger test for cointegration: test residuals

fit <- lm(he ~ c + sm) 
summary(fit)

z <- fit$residuals
adf.z <- ur.df(z, type = "none", selectlags = "BIC")
summary(adf.z)
#Part 2: Engle-Granger test for cointegration

he <- embed(as.numeric(log(raw.Data$HE.Close)), 2)
c <- embed(as.numeric(log(raw.Data$C.Close)), 2)
sm <- embed(as.numeric(log(raw.Data$SM.Close)), 2)

q <- embed(as.numeric(z), 2)[,2]
x <- cbind(he[,2], c[,2], sm[,2], q)

y1 <- data.frame(cbind(he[,1], 1, x))
names(y1) <- c("he.diff", "const", "he.diff.lag1", "c.diff.lag1", "sm.diff.lag1", "ecm")

y2 <- data.frame(cbind(c[,1], 1, x))
names(y2) <- c("c.diff", "const", "he.diff.lag1", "c.diff.lag1", "sm.diff.lag1", "ecm")

y3 <- data.frame(cbind(sm[,1], 1, x))
names(y3) <- c("sm.diff", "const", "he.diff.lag1", "c.diff.lag1", "sm.diff.lag1", "ecm")

head(y1)
head(y2)
head(y3)

fit1 <- lm(he.diff ~ const + he.diff.lag1 + c.diff.lag1 + sm.diff.lag1 + ecm - 1, data = y1)
summary(fit1)

fit2 <- lm(c.diff ~ const + he.diff.lag1 + c.diff.lag1 + sm.diff.lag1 + ecm - 1, data = y2)
summary(fit2)

fit3 <- lm(sm.diff ~ const + he.diff.lag1 + c.diff.lag1 + sm.diff.lag1 + ecm - 1, data = y3)
summary(fit3)

#Start time trend regression to get residuals and standard deviation of residuals for trading strategy

trend <- 1:length(z)

#regress z on each d and time index
df <- data.frame(Z = z, D1=D1, D2=D2, D3=D3, D4=D4, D5=D5, D6=D6, D7=D7, D9=D9, D10=D10, D11=D11, D12=D12,trend=trend)
z.mc <- lm(z~D1+D2+D3+D4+D5+D6+D7+D9+D10+D11+D12+ trend, data=df)
summary(z.mc)

e <- z.mc$residuals
delta <- sd(e)

#Now that we have the residuals and the standard deviation of the residuals, we can run the trading strategy
#He said to only test one of the trading simulations.  The 0.25 trading simulation
#This way we don't have to be too concerned with trying to figure out how to write each one.
#We need to see his notes in Julia about the stationary bootstrap.  The first part of the code is the trading signals
#We need to write something similar to this.

N <- length(dt)
X <- 0.25
#signal.long <- rep(0, length(e))
#signal.short <- rep(0, length(e))
signal <- rep(0, length(e))
signals <- rep(0, length(e))
  
  for(i in 1:N)
  {
    if (e[i] < -X * delta)
      signal[i] <- 1
    else if (e[i] > X * delta) 
      signal[i] <- -1
    else
      signal[i] <- 0
  signals[i] <- sign(signal[i])
  }
  return(signals)

#Once we have the trading simulation, we need to multiply the signal by the returns to get losses
#The returns are hog - b * corn - b * soy

return <- rep(0, N)

for(i in 1:N)
{
  return[i] <- (he[i] - fit$coefficients[2] * c[i] - fit$coefficients[3] * sm[i])
}

#Once we have the losses we compare a buy and hold strategy of hog futures to the trading strategy.

loss <- rep(0, N)

for(i in 1:N)
{
  loss[i] <- signals[i] * return[i]
}

#Calculate relative loss
#Returns or Prices?
#Right now we have prices - returns

d <- rep(0, N)
loss.d <- diff(loss[1:N])

long.0 <- diff(log((he[1:N])))
d <- long.0 - loss

#sullivan et al.--bootstrap
#still different because of hansen SPA test

write.csv(d, "losses.csv", quote = F, row.names = F)


#Then we can run the stationary bootstrap
statboot <- juliaEval("
                      ")
statboot <- juliaEval("
                      function StationaryBootstrap(y::Array{Float64,1}, m::Int64, B::Int64)
	                      N = length(y)
                        ystar = zeros(B, N)
                        q = 1 / m
                      
                        for b in 1:B
                          u = rand(1:N, N)
                          v = rand(N)
                      
                          for t in 2:N
                            if v[t] < q
                              u[t] = rand(1:N)
                            else
                              u[t] = u[t] + 1
                              if u[t] > N
                                u[t] = u[t] - N
                            end
                          end
                        end
                      
                        ystar[b,:] = y[u]
                      end
                      
                      ystar
                      end")

m <- 10
B <- 10000
dstar <- statboot(d, m, B)

#x <- t(x): transpose from julia


#And now the SPA test

#dbar <- mean(d)
#dbar.b <- apply(dstar, 2, mean)
#n <- nrow(dstar)
#w.hat.2 <- mean((sqrt(n) * dbar.b - sqrt(n) * dbar)^2)
#t.spa <- max((sqrt(n) * dbar) / sqrt(w.hat.2), 0.0)


spatest <- juliaEval("
                    function HansenSPATest(d::Array{Float64,1}, dstar::Array{Float64,2})
	                    dbar = mean(d)
                      dbar_b = mean(dstar,2)
                      (B,n) = size(dstar)
                      w_hat2 = mean((sqrt(n) * dbar_b - sqrt(n) * dbar).^2)
                      t_spa = max((sqrt(n) * dbar) / sqrt(w_hat2), 0.0)
                     
                      gl = max(0.0, dbar)
                      gu = dbar
                      rhs = -sqrt((w_hat2 / n) * 2 * log(log(n)))
                      ind = 0.0
                      if dbar >= rhs
                        ind = 1.0
                      end
                      gc = dbar * ind
                     
                      Zl = dstar - gl
                      Zc = dstar - gc
                      Zu = dstar - gu
                     
                      Zlbar = mean(Zl, 2)
                      Zcbar = mean(Zc, 2)
                      Zubar = mean(Zu, 2)
                     
                      z_spa_l = max.((sqrt(n) .* Zlbar) / sqrt(w_hat2), 0.0)
                      z_spa_c = max.((sqrt(n) .* Zcbar) / sqrt(w_hat2), 0.0)
                      z_spa_u = max.((sqrt(n) .* Zubar) / sqrt(w_hat2), 0.0)
                     
                      p_spa_l = 0.0
                      p_spa_c = 0.0
                      p_spa_u = 0.0
                     
                      for b in 1:B
                        if z_spa_l[b] > t_spa
                          p_spa_l += 1.0
                        end
                     
                        if z_spa_c[b] > t_spa
                          p_spa_c += 1.0
                        end
                     
                        if z_spa_u[b] > t_spa
                          p_spa_u += 1.0
                        end
                      end
                     
                      p_spa_l /= B
                      p_spa_c /= B
                      p_spa_u /= B
                     
                      return (p_spa_l, p_spa_c, p_spa_u)
                    end")


#Get the p-values?

(pl, pc, pu) = spatest(d, dstar)

#Do we need to copy the Julia code for the SPA test?
#Do we need to copy the Julia code for the stationary bootstrap as well?

#create a table that has the test SPA statistic, and then the p:upper, p:lower, p:middle
#0.05
#paragraph explaining what this means
#compare to what Liu finds